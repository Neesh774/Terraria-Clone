## Citations

[Terrain Gen](https://learn.64bitdragon.com/articles/computer-science/procedural-generation/the-diamond-square-algorithm)

[Textures](https://resourcepack.net/dandelion-resource-pack/)

[Mob Textures](https://pixelfrog-assets.itch.io/pixel-adventure-2)

[Background Image](https://www.deviantart.com/jonata-d/art/Mountain-Sprite-001-706211298)
